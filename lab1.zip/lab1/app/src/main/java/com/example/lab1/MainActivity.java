package com.example.lab1;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;


import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends Activity {

    Fragment1 frag1;
    Fragment2 frag2;
    FragmentTransaction fTrans;

    @BindView(R.id.btnAdd)
    Button btnAdd;
    @BindView(R.id.btnRemove)
    Button btnRemove;
    @BindView(R.id.btnReplace)
    Button btnReplace;
    @BindView(R.id.chbStack)
    CheckBox chbStack;
    @BindView(R.id.frgmCont)
    FrameLayout frgmCont;
    @BindView(R.id.LinearLayout1)
    LinearLayout LinearLayout1;

    @Override

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        frag1 = new Fragment1();
        frag2 = new Fragment2();

        chbStack = (CheckBox) findViewById(R.id.chbStack);
    }

    public void onClick(View v) {

        fTrans = getFragmentManager().beginTransaction();
        switch (v.getId()) {
            case R.id.btn1:
                // Создание обычного Toast сообщения
                Toast.makeText(MainActivity.this,
                        "Обычное Toast сообщение",
                        Toast.LENGTH_SHORT).show();
                break;
            case R.id.btnAdd:
                fTrans.add(R.id.frgmCont, frag1);

                break;
            case R.id.btnRemove:
                fTrans.remove(frag1);
                break;
            case R.id.btnReplace:
                fTrans.replace(R.id.frgmCont, frag2);
            default:
                break;

        }
        if (chbStack.isChecked()) fTrans.addToBackStack(null);
        fTrans.commit();

    }

    public void Toast(View view) {
        switch (view.getId()) {
            case R.id.btnAdd:
                // Создание обычного Toast сообщения
                Toast.makeText(MainActivity.this,
                        "Обычное Toast сообщение",
                        Toast.LENGTH_SHORT).show();
                break;

            case R.id.btnRemove:
                // Создание Toast сообщения
                Toast toast2 = Toast.makeText(MainActivity.this,
                        "Toast с позиционированием",
                        Toast.LENGTH_LONG);
                // Позиционирование Toast сообщения
                toast2.setGravity(Gravity.TOP, 0, 100);
                toast2.show();
                break;

            case R.id.btnReplace:
                // Создание Toast сообщения
                Toast toast3 = Toast.makeText(MainActivity.this,
                        "Toast с изображением",
                        Toast.LENGTH_LONG);

                toast3.show();
                break;
        }

    }
}